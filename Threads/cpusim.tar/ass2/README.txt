  Assignment 2
----------------

CIS 3110
Mar. 13, 2016

Author: Jessica Authier, 0849720

References
-----------

	In main.c
		lines 154-204, ... ;
		refreshed my strct and linked list skills with
		http://www.cprogramming.com/tutorial/c/lesson7.html,
		http://www.cprogramming.com/snippets/source-code/singly-linked-list-insert-remove-add-count
		and http://www.tutorialspoint.com/cprogramming/c_structures.htm


	In getThreads.c
		lines 98, 120, ... : 
		learned file redirection from 
		http://stackoverflow.com/questions/19467865/how-to-use-redirection-in-c-for-file-input
		
		lines 31-68, 160-166, 194-198, 203-218, 221-229,... :
		refreshed my strct and linked list skills with
		http://www.cprogramming.com/tutorial/c/lesson7.html,
		http://www.cprogramming.com/snippets/source-code/singly-linked-list-insert-remove-add-count
		and http://www.tutorialspoint.com/cprogramming/c_structures.htm
		

Compiling and Running
----------------------

to compile type 'make'
- the make file contains all the appropriate flags

to run type ./simcpu [-d] [-v] [-r <quantum>] < [fileName]


Limitations
------------

It is assumed that the input file is in the appropriate format.

Does not calculated the CPU utilization