Assignment 3

Jessica Authier
0849720

~~~~~~~~~~~~~~~~
dine.c used doc.oracle.com/cd/... , can google dinning philosophers in c to find it
For inspiration and help

used some of my code from A2 in holes.c

~~~~~~~~~~~~~~~~~

both programs have make files to compile and are run exactly 
like in the assignment instructions


~~~~~~~~
had problems accessing longbottom, so tested everything on
my ubuntu vm.

Also I was without power for a while on friday and wasn't able to get as much
done as i would have liked.
