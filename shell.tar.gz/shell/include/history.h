#ifndef history_h
#define history_h

#include "main.h"

int writeHistory(char *toWrite);
void readHistory();
void clearHistory();
int readnEntries(char* arg);

#endif
