#ifndef piping_h
#define piping_h

#include "main.h"

int checkPipe(char **args, int numArgs);
int piping(char **args, int numArgs);

#endif
